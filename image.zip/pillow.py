#This is an example pf a pillow (a image function ) in python

from PIL import Image  #I'm not installed yet

img = Image.open('mukesh.jpg')
print(img.size)
print(img.format)

img.sho()
