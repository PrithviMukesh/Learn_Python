#This is an example of combining the images

from PIL import Image
mukesh = Image.open('mukesh.jpg')
paste_image = Image.open('123.jpg')

area = (100,100,200, 200)

mukesh.paste(paste_image, area)
mukesh.show()
