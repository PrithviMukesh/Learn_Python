#This is an example of cropping images

from PIL import Image

img = Image.open('mukesh.jpg')
area = (100,100,200,200)
cropped_image = img.crop(area)
cropped_image.show()

img.show()