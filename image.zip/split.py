from PIL import Image
mukesh = Image.open('mukesh.jpg')
mukesh1 = Image.open('123.jpg')
r1, g1, b1 = mukesh.split()
r2, g2, b2 = mukesh1.split()

new_img = Image.merge("RGB", (r1, g2, b1))
new_img.show()


