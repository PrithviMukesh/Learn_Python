#his is an example of Image transformations
from PIL import Image

mukesh = Image.open('mukesh.jpg')
mukesh_resize = mukesh.resize((100, 100))
mukesh_flip = mukesh.transpose(Image.Flip_left_right)
mukesh_spin = mukesh.transpose(Image.Rotate_90)

mukesh.show()
mukesh.resize.show()
mukesh_flip.show()
mukesh_spin.show()

