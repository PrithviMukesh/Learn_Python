#This is an exampleof filters and modes

from PIL import Image
from PIL import ImageFilter

mukesh = Image.open('mukesh.jpg')
blur_mukesh = mukesh.filter(ImageFilter.BLUR)
detail = mukesh.filter(ImageFilter.DETAIL)
edges = mukesh.filter(ImageFilter.FIND_EDGES)

blur_mukesh.show()
detail.show()
edges.show()
