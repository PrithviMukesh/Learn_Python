#This is an example of download a csv file from Internet

from urllib import request

google_url = 'http://real-chart.finance.yahoo.com/table.csv?s=GOOG&d=5&e=24&f=2016&g=d&a=7&b=19&c=2004&ignore=.csv'

def download_file(csv_url):
    response = request.urlopen(csv_url)
    csv_file = response.read()
    csv_file_string = str(csv_file)
    lines = csv_file_string.split("\\n")
    dest_file = r'google.csv'
    fr = open(dest_file , "w")
    for line in lines:
        fr.write(line + "\n")
    fr.close()

download_file(google_url)
