#This is an example of Read and Write files
#Make the object for write

fw = open('sample.txt', 'w')
fw.write("I am Prithvi Mukesh\n")
fw.write("And I Love coding\n")
fw.write("Here are the samples....python,c sharp")
fw.close()

#Read the file using the python code
fr = open('sample.txt', 'r')
readed_file = fr.read()
print(readed_file)
fr.close()