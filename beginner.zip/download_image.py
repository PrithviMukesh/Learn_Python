#This is an python code to download an image
import random
import urllib.request

def download_img(url):
    name = random.randrange(1, 1000);
    full_name = str(name) + ".jpg";
    urllib.request.urlretrieve(url, full_name)
    print("Image is downloaded")

download_img("http://www.kendirfuar.com/img/sabitler/eskiler/6-32bfd51a01a1a255da04110314fde78a.jpg")