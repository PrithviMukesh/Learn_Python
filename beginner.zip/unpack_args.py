#This is an example of unpacking arguments

def health_calculator(your_age , apples_ate , cigs_smoked):
    health = (100-your_age) + (apples_ate *3.5) -(cigs_smoked *2)
    print(health)

my_data = [20 , 30 , 0]
health_calculator(my_data[0] , my_data[1] , my_data[2])
health_calculator(*my_data)