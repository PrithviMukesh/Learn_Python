#This is an example of if and else

name1 = input("enter the name\n")
name = name1
age = 20

if name is "mukesh":
    print("The name is mukesh")
elif name is "pandi":
    print ("The name pandi")
elif name is "neppu":
    print("The name is neppu")
else:
    print("No matches found")

if age<21:
    print("You are eligible for voting")