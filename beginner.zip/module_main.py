#This is an imported module example
import prithvi
import random

prithvi.name()
x = random.randrange(1, 10)
print(x)