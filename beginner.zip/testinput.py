
name = input("enter the name")
print(name)