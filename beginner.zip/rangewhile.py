#This is an example of Range and while loop

for x in range(10, 40, 2):
    print(x)

age = 5
while age<15:
    print('age is',str(age))
    age += 1

