#This is an example of keyword arguments
def aboutme(name = 'Prithvi', action = 'eats' , item = 'fish'):
    print (name ,action, item)

aboutme()
aboutme(name = 'mukesh')
aboutme(item = 'chicken')
aboutme('prithvi', 'is', 'awesome')