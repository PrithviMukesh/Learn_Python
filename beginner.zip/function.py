#This is an example of python functions

def myfunction():
    print("This is prithvi's Function example")
myfunction()

def doller_to_rupees(dolleramount):
    converted = dolleramount * 72
    print(converted)

doller_to_rupees(10)
doller_to_rupees(10)
doller_to_rupees(10)
