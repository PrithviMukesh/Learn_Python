#This is an example of default values and arguments

def gender_from_database(sex = 'Unknown'):
    if sex is 'm':
        sex = "Male"
        print("The Gender you entered is ", sex)
    elif sex is 'f':
        sex = "female"
        print("The Gender you entered is ", sex)
    else:
        print("Unknown")



gender_from_database('m')
gender_from_database('f')
gender_from_database()