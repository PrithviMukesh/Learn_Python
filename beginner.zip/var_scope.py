#This is an example of variable scope

a=10

def f1():
    a=20
    print(a)
def f2():
    print(a)

f1()
f2()
