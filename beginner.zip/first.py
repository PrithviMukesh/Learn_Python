print("Hello, World!")
a = 10
b = 'prithvi'

# This is the type of variable creation in python
print(a, "\n" +b)