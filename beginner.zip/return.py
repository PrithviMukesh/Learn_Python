def dating_age(my_age):
    girl_age = my_age/2 +7
    return girl_age

prithvi_age = dating_age(20)
print("prithvi dating value is", prithvi_age, " or older")