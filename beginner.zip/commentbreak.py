#Thia is an example of comments

magicNumber = 9

#The magic number is declared and this is the comment

'''
hfjfhfhf
hjhfjfhf
fhfhgjgh
'''
#the part is multi comments

for n in range(10):
    if n is magicNumber:
        print (n ," is magic number")
        break
    else:
        print(n)
#print("There is no magic number \n so I amprinting all the numbers in the range")