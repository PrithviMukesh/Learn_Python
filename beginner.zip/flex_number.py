#This is an example of Flexible numbers and arguments

def add_number(*add):
    total = 10
    for x in add:
        total += x
    print(total)

add_number(5)
add_number(3)
add_number(3,2,5)
add_number(3455,3455,34455)