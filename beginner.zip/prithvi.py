#This is an module file we call after we declared this function

def name():
    print("My name is Prithvi")