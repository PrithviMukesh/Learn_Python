#This is an example of sets and walmart trip

items  = {'laptop' , 'mobile', 'charger' , 'battery' , 'laptop' }
print(items)

if 'laptop' in items:
    print("Its already there")
else:
    print("'laptop' You need to add")