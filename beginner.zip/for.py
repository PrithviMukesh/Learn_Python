#This is an example of for loop
names = ['prithvi', 'mukesh', 'neppu', 'vijay', 'pandi', 'hari']
name = [1,2,3,4,5]
nam = ['hfjfgfyfrvrhfhfhfhf']

for f1 in nam:
    print (f1)



