#This is an example of continue

numbers = [12, 15, 18, 25, 30]
print("The numbers are")
number = 13
for n in range(50):
    if n in numbers:
        print(n, "found")
        continue
    print(n)
