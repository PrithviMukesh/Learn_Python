#This is an example of dictionary in python

need = {'laptop' : ' used for programming' , 'mobile':' for calling', 'charger' : ' for charging'}

print(need)
print(need.items())

for k, v in need.items():
    print(k + " use:  " + v)