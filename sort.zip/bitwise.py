
 # -------BINARY AND--------
a = 20
b = 50
c = a & b
print(c)
# ----------BINARY RIGHT SHIFT-----
x = 230
y = x >> 2
print(y)