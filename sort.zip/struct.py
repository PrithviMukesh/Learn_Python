from struct import *

#store as bytes data

packed_data = pack('iif', 4, 5, 6.66)
print(packed_data)

print(calcsize('i'))
print(calcsize('i'))
print(calcsize('iif'))

original_data = unpack('iif', packed_data)
print(original_data)