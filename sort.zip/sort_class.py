from operator import attrgetter

class User:
    def __init__(self, x, y):
        self.name = x
        self.id = y

    def __repr__(self):
        return self.name+ " : "+str(self.id)


users = [
    User('prithvi', 45),
    User('mukesh', 45),
    User('vijay', 45),
    User('prem', 45),
    User('arul', 45),
    User('neppu', 45)
]

print('-----Default Sorting------')
for item in users:
    print(item)

print('------sort by name-----')
for item in sorted(users, key=attrgetter('name')):
    print(item)

print('---sort by id---')
 d = sorted(users, key=attrgetter('id'))
for item in d:
    print(item)