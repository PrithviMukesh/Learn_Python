
income = [20,30,40,50]

def map_function(dollaers):
    return dollaers * 2

d = list(map(map_function, income))
print(d)
