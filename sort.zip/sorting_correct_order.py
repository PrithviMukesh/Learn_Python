from operator import itemgetter

users = [
    {'fname' : 'prithvi', 'lname' :'mukesh'},
    {'fname' : 'prithvi', 'lname' :'aantony'},
    {'fname' : 'prem', 'lname' :'selvam'},
    {'fname' : 'vijay', 'lname' :'arasu'},
    {'fname' : 'neppu', 'lname' :'nepps'},
    {'fname' : 'arul', 'lname' :'pandi'}
]

for item in sorted(users, key=itemgetter('fname')):
    print(item)

print('--------')
for item in sorted(users, key=itemgetter('fname', 'lname')):
    print(item)