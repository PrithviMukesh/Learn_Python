import  heapq
from operator import attrgetter

grades = [23, 897,453, 625, 987,423]
print(sorted(grades))
print(min(grades))
print(max(grades))

print(heapq.nlargest(3, grades))

stocks = [
    {'Google' : 234.23,'price' : 234.2},
    {'Facebook' : 200.89,'price' : 334.2},
    {'Yahoo' : 300.12,'price' : 454.2},
    {'LinkedIn' : 123.90,'price' : 534.2},
    {'Whatsapp' : 456.23,'price' : 4434.2}
]

print(heapq.nsmallest(2,stocks, key=lambda stock: stock['price']))