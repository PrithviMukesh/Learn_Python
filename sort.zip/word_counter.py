from collections import Counter

text = " This is prithvi mukesh, I love  soru "
words = text.split()

counter = Counter(words)
top_words = counter.most_common(2)
print(top_words)
print(counter)