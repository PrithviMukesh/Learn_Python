#This is an example of web crawler

import requests
from bs4 import BeautifulSoup


def trade_spider(max_pages):
    page = 2
    while page <= max_pages:
        url = 'http://www.amazon.in/s/ref=sr_pg_2?rh=i%3Aaps%2Ck%3Ahard+drives&page=' +str(page)+ '&keywords=hard+drives&ie=UTF8&qid=1466774228&spIA=B011J4C1MA,B00F5CKWBA'
        print(url)
        source_code = requests.get(url)
        plain_text = source_code.text
        soup = BeautifulSoup(plain_text)
        for link in soup.findAll('a', {'class': 'a-link-normal s-access-detail-page  a-text-normal'}):
            href = "http://www.amazon.in" + link.get('href')
            title = link.string
            print(href)
            print(title)
            #single_item_data(href)
        page += 1

def single_item_data(item_url):
    source_code = requests.get(item_url)
    plain_text = source_code.text
    soup = BeautifulSoup(plain_text)
    for item_name in soup.finAll('div', {'class' : 'thisdivision-yes'}):
        print(item_name.string)
        for link in soup.findAll('a'):
            href = "http://amazon.in" + link.get(href)
            print(href)
trade_spider(2)
