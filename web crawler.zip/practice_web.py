import requests
from bs4 import BeautifulSoup

def track_spider(max_pages):
    page = 1
    while page <= max_pages:
        url = 'https://thenewboston.com/search.php?type=0&sort=reputation&page==' + str(page)
        source_code = requests.get(url, allow_redirects=False)
        plain_text = source_code.text('ascii', 'replace')
        soup = BeautifulSoup(plain_text, 'html.parser')
        for link in soup.findAll('a', {'class' : 'user-name'}):
            href = link.get('href')
            title = link.string
            print(href)
            print(title)
            single_data_item(href)
            page +=1

def single_data_item(item_url):
    source_code = requests.get(item_url)
    plain_text = source_code.text('ascii', 'replace')
    soup = BeautifulSoup(plain_text, 'html.parser')
    for link in soup.findAll('img', {'class' :'iamgclass'})
        photo = "https://thenewboston.com" +link.get('src')
        print(photo)
     for link in soup.findAll('a'):
        href = link.get('href')
        print(href)


track_spider(3)
