#This is an example of an multiple Inheritance

class Mario():

    def mario_name(self):
        print("I am Mario \n And my name is Prithvi")

class grow():

    def growup_mario(self):
        print("I grown up ")

class new_mario(Mario, grow):
    pass

mario = new_mario()
mario.mario_name()
mario.growup_mario()
