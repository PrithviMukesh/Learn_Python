

income = [20,30,40,50]

def map_function(dollaers):
    return dollaers * 2

d = map_function()
print(d)