class Enemy:
    def __init__(self, x):
        self.energy = x

    def energy1(self):
        print(self.energy)

enemy2 = Enemy(19)
enemy2.energy1()
