#This is an example of unpacking list

date, name, price = ['December 28 02:01:2012', 'Prithvi Mukesh', '32.0']
print(name)
print(date)
print(price)

def calculate(grades):
    first, *middle = grades
    avg =sum(middle) / len(middle)
    print(avg)

calculate([23,2,2,2,3])