#This is minimum and maximum and sorted arrys

stocks = {
    'Google' : 234.23,
    'Facebook' : 200.89,
    'Yahoo' : 300.12,
    'LinkedIn' : 123.90,
    'Whatsapp' : 456.23
}
print(min(zip(stocks.keys(),stocks.values())))
print(max(zip(stocks.keys(),stocks.values())))
print(sorted(zip(stocks.keys(),stocks.values())))
print(min(zip(stocks.values(), stocks.keys())))