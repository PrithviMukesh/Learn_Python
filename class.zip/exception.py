#This is an example of Exception in python

while True:
    try:
        number = int(input("Please enter a number to calculate\n"))
        print(2/number)
        continue
    except ValueError:
        print("Please enter only numbers\n")
    except ZeroDivisionError:
        print("Don't give 0 as a input\n")
    except:
        break
    finally:
        print("Loop completed\n")

