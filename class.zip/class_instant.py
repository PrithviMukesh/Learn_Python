
#This is an example of classes and instant variables

class Girl:
    gender = 'female'

    def __init__(self, name):
        self.name1 = name
        print(self.name1)

r = Girl('rapheal')
s = Girl('sunny')

print(r.gender)

print(s.gender)
