#This is an example of inheritance and example

class Parent():
    def my_last_name(self):
        print('selvam')
    def print_my_fullname(self):
        print("My full name is Prithvi Mukesh")

class child(Parent):
    def my_first_name(self):
        print('mukesh')
    def my_last_name(self):
        print('sevugan')

myname = child()
myname.my_first_name()
myname.my_last_name()
myname.print_my_fullname()