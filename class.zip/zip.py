#This is an example of zip in python

first = ['prithvi', 'vijay', 'neppo', 'arul']
last = ['mukesh', 'arasu', 'lian', 'pandi']

zipped = zip(first,last)
for a,b in zipped:
    print(a,b)