#This is an example of init function

class Enemy:
    def __init__(self,c):
        print("This is an Initialization of the program \n\twithout calling the function")
        self.c = 20
    def pass_arg(self):
        self.a = 10
        self.b = 20
        print(self.a+self.b+self.c)


enemy1 = Enemy(5)
enemy1.pass_arg()


