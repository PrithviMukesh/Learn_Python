answer = lambda x:x*3
print(answer(7))