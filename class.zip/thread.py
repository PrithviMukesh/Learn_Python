#This is an example of Thread

import threading
class Thread_Example(threading.Thread):
    def run(self):
        for _ in range(10):
            print(threading.current_thread().getName())


Thread1 = Thread_Example(name='send message')
Thread2 = Thread_Example(name='Receive message')
Thread1.start()
Thread2.start()